export * from './Step1BasicDetails';
export * from './Step1LoanType';
export * from './Step2KycVerification';
export * from './Step2PersonalInfo';
export * from './Step3EmploymentIncome';
export * from './Step3KYC';
export * from './Step4Address';
export * from './Step4LoanRequirement';
export * from './Step5AddressDetails';
export * from './Step5Employment';
export * from './Step6BankVerification';
export * from './Step6CoApplicant';
export * from './Step7Documents';
export * from './Step7DocumentUpload';
export * from './Step8Review';
export * from './Step8ReviewConsent';


