# LendSwift &mdash; Enterprise Digital Lending Origination Platform

[![TypeScript](https://img.shields.io/badge/TypeScript-5.5-blue.svg?logo=typescript)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-18.3-61dafb.svg?logo=react)](https://reactjs.org/)
[![Vite](https://img.shields.io/badge/Vite-5.4-646CFF.svg?logo=vite)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.4-38B2AC.svg?logo=tailwind-css)](https://tailwindcss.com/)
[![Cypress](https://img.shields.io/badge/Cypress-13.15-04C389.svg?logo=cypress)](https://www.cypress.io/)
[![Accessibility](https://img.shields.io/badge/WCAG-2.1_AA_Compliant-success.svg)](https://www.w3.org/WAI/standards-guidelines/wcag/)
[![Security](https://img.shields.io/badge/Encryption-AES--256--GCM-darkgreen.svg)](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto)
[![RBI Digital Lending](https://img.shields.io/badge/RBI-Master_Directions_Compliant-indigo.svg)](https://www.rbi.org.in/)

**LendSwift** is a state-of-the-art digital lending origination platform engineered for Non-Banking Financial Companies (NBFC-ICC) and commercial banks in India. It guides prospective borrowers through an 8-step loan application journey engineered to comply with the **Reserve Bank of India (RBI) Master Directions on Digital Lending**, the **Credit Information Companies Regulation Act (CICRA 2005)**, and the **Information Technology Act 2000**.

---

## Key Architectural & Compliance Highlights

- **Statutory Indian Identity Verification:**
  - **NSDL PAN Verification:** Real-time format validation and 4th-character entity checks (Individual `'P'` for Retail/Home loans; Corporate `'C'` or Firm `'F'` for Commercial loans).
  - **UIDAI Verhoeff Checksum Algorithm:** True mathematical implementation of the dihedral group $D_5$ algorithm across multiplication, permutation, and inverse matrices for 12-digit Aadhaar verification.
  - **15-Character GSTIN Validation:** Validates state code prefix, PAN structure, and entity check digits for business borrowers.
  - **Offline PIN Code Engine:** 100+ Tier-1/2/3 Indian postal codes with instant city and state autofill.
- **Client-Side AES-256-GCM State Encryption:**
  - Uses the Web Crypto API (`window.crypto.subtle`) with PBKDF2 key derivation and a random 12-byte IV per write.
  - Zero plaintext PII stored in `localStorage`, meeting RBI guidelines on borrower data privacy.
  - 30-second debounced auto-save engine with resumption prompts and tamper detection.
- **Dynamic Risk Underwriting & Affordability Meter:**
  - Dynamic Step 6 (Co-Applicant & Guarantor) gating: mandatory for Home Loans, conditional for high-ticket Personal (> ₹5L) and Business (> ₹20L) loans.
  - Pre-Approval Key Fact Statement (KFS) calculating reducing-balance monthly EMI, total interest, processing fees, and GST.
  - 50% Fixed Obligation to Income Ratio (FOIR) Affordability Meter comparing EMI against aggregate household income.
- **Client-Side Document Optimization & E-Signature:**
  - Dynamic upload checklist tailored to loan category and employment type.
  - Client-side HTML5 canvas image compression with automatic size reduction and metadata badges.
  - High-precision borrower e-signature pad adhering to the Information Technology Act 2000.
- **4 Mandatory Statutory RBI Declarations:**
  - Granular, independent consent checkboxes with no pre-checked defaults (accuracy declaration, CICRA bureau authorization, KFS terms acceptance, and electronic communications consent).
- **Automated Accessibility Testing:**
  - Full WCAG 2.1 AA compliance verified via `cypress-axe` integration across all 8 steps and modal dialogs.

---

## Technical Stack

| Layer | Technology |
| :--- | :--- |
| **Frontend Framework** | [React 18.3](https://react.dev/) + [TypeScript 5.5](https://www.typescriptlang.org/) |
| **Build & Dev Server** | [Vite 5.4](https://vitejs.dev/) |
| **Form Engine** | [React Hook Form 7.53](https://react-hook-form.com/) (Uncontrolled refs for $O(1)$ input performance) |
| **Validation Layer** | [Zod 3.23](https://zod.dev/) (Modular atomic step schemas & discriminated unions) |
| **Styling & Design System** | [Tailwind CSS 3.4](https://tailwindcss.com/) with curated FinTech color tokens |
| **Cryptographic Layer** | Web Crypto API (`SubtleCrypto` AES-256-GCM with PBKDF2) |
| **Signature Capture** | [react-signature-canvas 1.1.0](https://github.com/agilgur5/react-signature-canvas) |
| **Document Dropzone** | [react-dropzone 14.3.5](https://react-dropzone.js.org/) |
| **E2E & A11y Testing** | [Cypress 13.15](https://www.cypress.io/) + [axe-core / cypress-axe](https://github.com/dequelabs/axe-core) |

---

## Getting Started

### Prerequisites

- **Node.js**: `v18.0.0` or higher (Node 20 LTS recommended)
- **npm**: `v9.0.0` or higher

### Installation

Clone the repository and install all dependencies:

```bash
git clone https://github.com/shreyaskaraiya321/LendSwift.git
cd LendSwift
npm install
```

### Running Locally in Development

Start the local Vite development server:

```bash
npm run dev
```

The application will launch at `http://localhost:5173`. Hot Module Replacement (HMR) is enabled.

### Production Build & Preview

Validate TypeScript types and compile the optimized production bundle:

```bash
npm run build
```

Preview the production build locally:

```bash
npm run preview
```

---

## Testing & Quality Assurance

LendSwift ships with a comprehensive end-to-end and accessibility test suite under `cypress/e2e/`.

### Run Tests in Headless Mode

```bash
npx cypress run
```

### Run Tests with Interactive Cypress UI

```bash
npx cypress open
```

### Test Suite Catalog

| Spec File | Journey Covered |
| :--- | :--- |
| `cypress/e2e/accessibility-audit.cy.js` | **Automated WCAG 2.1 AA audit (`cy.injectAxe()`, `cy.checkA11y()`) across all 8 steps and modals** |
| `cypress/e2e/personal-loan-happy-path.cy.js` | Full salaried personal loan application, document upload, signature, and submission |
| `cypress/e2e/home-loan-happy-path.cy.js` | High-ticket Home Loan verifying mandatory Step 6 Co-Applicant inclusion and property deeds |
| `cypress/e2e/business-loan-happy-path.cy.js` | Commercial MSME flow validating 15-char GSTIN, annual turnover, and enterprise vetting |
| `cypress/e2e/validation-errors.cy.js` | Boundary checks, invalid PAN/Aadhaar formats, and live validation error triggers |
| `cypress/e2e/autosave-resume.cy.js` | AES-256-GCM persistence, page reload, resume dialog, and decrypted state restoration |

### Linting & Static Analysis

Ensure zero code style and syntax warnings:

```bash
npm run lint
```

---

## Application Architecture

Detailed technical architecture documentation is available in [ARCHITECTURE.md](file:///d:/LendSwift/ARCHITECTURE.md). Key topics include:

1. **The Wizard State Machine:** Dynamic routing topology and predicate-based step visibility.
2. **React Hook Form Ref Architecture:** Memory isolation and uncontrolled input models eliminating unnecessary re-renders.
3. **Zod Modular Composition:** Discriminated unions (`z.discriminatedUnion`) and cross-field `superRefine` business logic.
4. **AES-256-GCM Cryptographic Flow:** Web Crypto API initialization vectors, AEAD authentication tags, and tamper protection.
5. **Cross-Step Dependency Matrix:** Complete mapping of data flows between loan categories, KYC verifications, income declarations, and KFS summaries.

---

## Zero-Error Verification Matrix

Every release is validated against strict automated quality thresholds:

- [x] **TypeScript Compilation:** Zero errors (`tsc -b` clean).
- [x] **ESLint Check:** Zero warnings and zero errors (`--max-warnings 0`).
- [x] **Production Bundle:** Successfully bundled with code splitting and source maps.
- [x] **WCAG 2.1 AA Accessibility:** 0 critical, serious, or moderate violations detected by `axe-core`.
- [x] **State Security:** Zero plaintext PII persisted to browser storage.

---

## License

This project is licensed under the MIT License. Developed for enterprise digital lending compliance.
